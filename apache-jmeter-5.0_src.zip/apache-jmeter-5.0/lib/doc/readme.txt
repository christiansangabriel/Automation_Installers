This directory hosts jars needed for documentation generation.
They are not needed at run-time.
